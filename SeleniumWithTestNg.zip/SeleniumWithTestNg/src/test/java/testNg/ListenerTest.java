package testNg;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

//@Listeners(listeners.CustomListeners.class)
public class ListenerTest {

    @Test
    public void test1() {
        int x = 10;
        int y = 10;
        Assert.assertEquals(x, y);
    }

    @Test
    public void test2() {
        Assert.fail("I am falling");
    }
}
