package testNg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

public class ParallelTest {

    @Test
    void firstTest() {
        try {
            //Get the chrome driver relative location which is in "configuration.properties file"
            Properties properties = new Properties();
            properties.load(ParallelTest.class.getClassLoader().getResourceAsStream("configuration.properties")); //load configuration file

            ChromeOptions chromeOptions = new ChromeOptions();
            chromeOptions.addArguments("start-maximized");
            //Launch Selenium
            System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + properties.getProperty("chrome_driver_path"));
            WebDriver webDriver = new ChromeDriver(chromeOptions);

            webDriver.get("https://www.google.com/");

            Thread.sleep(5000);  // Let the user actually see something!
            WebElement searchBox = webDriver.findElement(By.name("q"));
            searchBox.sendKeys("ChromeDriver");
            searchBox.submit();
            Thread.sleep(5000);  // Let the user actually see something!
            webDriver.quit();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    public void secondTest() {
        try {
            //Get the chrome driver relative location which is in "configuration.properties file"
            Properties properties = new Properties();
            properties.load(ParallelTest.class.getClassLoader().getResourceAsStream("configuration.properties")); //load configuration file

            ChromeOptions chromeOptions = new ChromeOptions();
            chromeOptions.addArguments("start-maximized");
            //Launch Selenium
            System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + properties.getProperty("chrome_driver_path"));
            WebDriver webDriver = new ChromeDriver(chromeOptions);

            webDriver.get("https://www.google.com/");

            Thread.sleep(5000);  // Let the user actually see something!
            WebElement searchBox = webDriver.findElement(By.name("q"));
            searchBox.sendKeys("ChromeDriver");
            searchBox.submit();
            Thread.sleep(5000);  // Let the user actually see something!
            webDriver.quit();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
