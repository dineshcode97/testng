package testNg;

import org.testng.Assert;
import org.testng.annotations.Test;

public class DependencyTest {

    @Test
    public void test1() {
        System.out.println("I am test 1");
       // Assert.fail();
    }

    @Test(dependsOnMethods = {"test1"})
    public void test2() {
        System.out.println("I am test 2");
    }

    @Test(dependsOnMethods = {"test1", "test2"}) //test3 will be executed only if test1 and test2 passes
    public void test3() {
        System.out.println("I am test 3");
    }
}
