package testNg;

import org.testng.annotations.Test;

public class groupingTest {
    @Test(groups = {"sanity"})
    public void test1(){
        System.out.println("I am test1");
    }

    @Test(groups = {"sanity"})
    public void test2(){
        System.out.println("I am test2");
    }

    @Test(groups = {"Regression"})
    public void test3(){
        System.out.println("I am test3");
    }

    @Test(groups = {"Regression"})
    public void test4(){
        System.out.println("I am test42");
    }

    @Test(groups = {"sanity", "Regression"})
    public void test5(){
        System.out.println("I am test5");
    }
}
