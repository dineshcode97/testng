package testNg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Properties;

public class BasicTests {

    @Test(priority = 3)
    public void LaunchSeleniumAndGoToTimesOfIndia() {
        try {
            //Get the chrome driver relative location which is in "configuration.properties file"
            Properties properties = new Properties();
            properties.load(BasicTests.class.getClassLoader().getResourceAsStream("configuration.properties")); //load configuration file

            ChromeOptions chromeOptions = new ChromeOptions();
            chromeOptions.addArguments("start-maximized");
            //Launch Selenium
            System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + properties.getProperty("chrome_driver_path"));
            WebDriver webDriver = new ChromeDriver(chromeOptions);

            webDriver.get("https://www.google.com/");

            Thread.sleep(5000);  // Let the user actually see something!
            WebElement searchBox = webDriver.findElement(By.name("q"));
            searchBox.sendKeys("times of India");
            searchBox.submit();
            Thread.sleep(5000);  // Let the user actually see something!
            webDriver.quit();

        } catch(Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test(priority = 1)
    public void sampleMethod() {
        System.out.println("My Name is Ganesh");
    }

    @Test(priority = 2)
    public void testFail() {
        //Assert.fail("I am a failed test");

        System.out.println("I am a failed test");
    }

    @Test(enabled = false,priority = 5)
    public void testDisabled() {
        //Assert.fail("I am a failed test");

        System.out.println("I am a disabled test");
    }
}
