package listeners;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class CustomListeners implements ITestListener {

    public void onStart(ITestContext context) {
        System.out.println("Test Execution started at time: " + context.getStartDate());
    }

    public void onTestFailure(ITestResult result) {
        System.out.println("Coming from listeners, execution status: " + result.getStatus());
    }
}
